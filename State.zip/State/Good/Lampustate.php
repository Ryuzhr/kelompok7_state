<?php

interface LampuState {
 public function switchState();
 public function getColor();   
}
?>